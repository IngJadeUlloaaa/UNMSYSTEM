# -*- coding: utf-8 -*-
# from odoo import http


# class UnmSystem(http.Controller):
#     @http.route('/unm_system/unm_system', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/unm_system/unm_system/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('unm_system.listing', {
#             'root': '/unm_system/unm_system',
#             'objects': http.request.env['unm_system.unm_system'].search([]),
#         })

#     @http.route('/unm_system/unm_system/objects/<model("unm_system.unm_system"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('unm_system.object', {
#             'object': obj
#         })
