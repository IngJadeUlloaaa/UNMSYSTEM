# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class unm_system(models.Model):
#     _name = 'unm_system.unm_system'
#     _description = 'unm_system.unm_system'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
