/** @odoo-module **/

import { registry } from '@web/core/registry';
const { Component } = owl;

export class NuevoIngresoForm extends Component {
    setup() {
        // No es necesario hacer nada aquí en este momento
    }

    async backToWelcome(){
        try {
            window.location.replace('/web#action=owl.action_principal');
        } catch {
            console.log('Error al dirigir a la interfaz', error);
        }
    }
}

NuevoIngresoForm.template = 'owl.NuevoIngresoForm';
registry.category('actions').add('owl.action_nuevo_ingreso_form', NuevoIngresoForm);