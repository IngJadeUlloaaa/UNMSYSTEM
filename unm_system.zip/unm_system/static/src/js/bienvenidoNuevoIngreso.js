/** @odoo-module **/

import { registry } from '@web/core/registry';
const { Component } = owl;

export class BienvenidoNuevoIngreso extends Component {
    setup() {
        // No es necesario hacer nada aquí en este momento
    }

    async toFormNewStudent() {
        try {
            window.location.replace('/web#action=owl.action_nuevo_ingreso_form');
        } catch {
            console.log('Error al dirigir a la interfaz', error);
        }
    }
}

BienvenidoNuevoIngreso.template = 'owl.BienvenidoNuevoIngreso';
registry.category('actions').add('owl.action_bienvenido_nuevo_ingreso', BienvenidoNuevoIngreso);