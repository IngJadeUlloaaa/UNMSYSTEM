/** @odoo-module **/
import { registry } from '@web/core/registry';
const { Component, useRef } = owl;
import { getCookie } from './cookieReingresos.js';

/* ================================================================================= */
/* ================================= PUT ESTUDIANTES =============================== */
/* ================================================================================= */
const URL_ESTUDIANTES_PUT = 'https://192.168.23.248:4500/api/v1/matricula/estudiantes';

/* ================================================================================= */
/* ================================= GET MUNICIPIOS ================================ */
/* ================================================================================= */
const URL_MUNICIPIOS_GET = 'https://192.168.23.248:4500/api/v1/matricula/municipios/search?limit=10&offset=0&order=asc';

/* ================================================================================= */
/* =============================== ZONAS PROCEDENCIAS ============================== */
/* ================================================================================= */
const URL_ZONAS_PROCEDENCIAS_GET = 'https://192.168.23.248:4500/api/v1/matricula/zonas';

/* ================================================================================= */
/* ===================================== ETNIAS ==================================== */
/* ================================================================================= */
const URL_ETNIAS_GET = 'https://192.168.23.248:4500/api/v1/matricula/etnias';

/* ================================================================================= */
/* =================================== PAISES GET ================================== */
/* ================================================================================= */
const URL_PAISES_GET = 'https://192.168.23.248:4500/api/v1/matricula/paises/search?limit=192&offset=0&order=asc';

export class Reingreso extends Component {
    setup() {
        this.token = getCookie('reingreso_Token');
        this.studentName = useRef(''); // Crear una referencia para almacenar el nombre del estudiante

        if (!this.token) {
            alert("Sesión no válida. Por favor, inicie sesión nuevamente.");
            window.location.replace('/web#action=owl.action_login');
        } else {
            console.log("Token disponible en Reingreso:", this.token);

            const payload = this.decodeToken(this.token);
            console.log("Payload decodificado:", payload); // Verifica el contenido del payload

            if (payload && payload.nombres) {
                this.studentName.current = payload.nombres; // Asignar el nombre del estudiante
                console.log("Nombre del estudiante obtenido:", this.studentName.current);
            } else {
                console.error("No se pudo obtener el nombre del estudiante del token.");
            }

            // Llamar a la función para obtener y poblar los municipios
            this.fetchMunicipios();
            this.fetchZonaProcedencias();
            this.fetchEtnias();
            this.fetchPaises();
        }
    }

    // Función para decodificar Base64
    decodeBase64(data) {
        const buff = Buffer.from(data, "base64");
        return buff.toString("utf8");
    }

    // Función para decodificar el token
    decodeToken(token) {
        const tokenPayload = token?.split(".")[1];
        if (tokenPayload) {
            try {
                const payload = this.decodeBase64(tokenPayload);
                console.log("Token decodificado:", payload); // Agrega esta línea para verificar el contenido
                return JSON.parse(payload); // Asumiendo que el payload es un objeto JSON
            } catch (e) {
                console.error("Error al decodificar el token:", e);
            }
        }
    }

    /* ================================================================================= */
    /* ================================= GET MUNICIPIOS ================================ */
    /* ================================================================================= */
    async fetchMunicipios() {
        try {
            let response = await fetch(URL_MUNICIPIOS_GET, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "authorization": `Bearer ${this.token}`
                },
                credentials: 'include'
            });

            if (response.ok) {
                let data = await response.json();
                console.log('Municipios obtenidos: ', data);
                this.populateMunicipiosSelect(data);
            } else {
                console.error('Error en la respuesta: ', await response.text());
                alert("Error al obtener los municipios.");
            }
        } catch (error) {
            console.error("Ocurrió un error al intentar conectarse con el servidor:", error);
            alert("Ocurrió un error al intentar conectarse con el servidor.");
        }
    }

    populateMunicipiosSelect(municipios) {
        const selectMunicipios = document.getElementById('municipioOrigenStudent');

        // Limpiar el select antes de agregar nuevas opciones
        selectMunicipios.innerHTML = '<option value=""></option>';

        // Recorrer los municipios y agregar opciones al select
        municipios.forEach(municipio => {
            const option = document.createElement('option');
            option.value = municipio.id;  // Asegúrate de que 'id' sea el campo correcto
            option.textContent = municipio.nombre;  // Asegúrate de que 'nombre' sea el campo correcto
            selectMunicipios.appendChild(option);
        });
    }

    /* ================================================================================= */
    /* ============================ GET ZONAS PROCEDENCIAS ============================= */
    /* ================================================================================= */
    async fetchZonaProcedencias() {
        try {
            let response = await fetch(URL_ZONAS_PROCEDENCIAS_GET, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "authorization": `Bearer ${this.token}`
                },
                credentials: 'include'
            });

            if (response.ok) {
                let dataZonaProcedencias = await response.json();
                console.log('Zonas de Procedencias obtenidas: ', dataZonaProcedencias);
                this.zonaProcedenciasSelect(dataZonaProcedencias);
            } else {
                console.error('Error en la respuesta: ', await response.text());
                alert("Error al obtener las zonas de procedencias.");
            }
        } catch (error) {
            console.error("Ocurrió un error al intentar conectarse con el servidor:", error);
            alert("Ocurrió un error al intentar conectarse con el servidor.");
        }
    }

    zonaProcedenciasSelect(zonaProcedencias) {
        const selectzonaProcedencias = document.getElementById('zonaProcedenciaStudent');

        // Limpiar el select antes de agregar nuevas opciones
        selectzonaProcedencias.innerHTML = '<option value=""></option>';

        // Recorrer los municipios y agregar opciones al select
        zonaProcedencias.forEach(zonaProcedencia => {
            const option = document.createElement('option');
            option.value = zonaProcedencia.id;  // Asegúrate de que 'id' sea el campo correcto
            option.textContent = zonaProcedencia.nombre;  // Asegúrate de que 'nombre' sea el campo correcto
            selectzonaProcedencias.appendChild(option);
        });
    }

    /* ================================================================================= */
    /* ===================================== ETNIAS ==================================== */
    /* ================================================================================= */
    async fetchEtnias() {
        try {
            let response = await fetch(URL_ETNIAS_GET, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "authorization": `Bearer ${this.token}`
                },
                credentials: 'include'
            });

            if (response.ok) {
                let dataEtnia = await response.json();
                console.log('Etnias obtenidas: ', dataEtnia);
                this.etniasSelect(dataEtnia);
            } else {
                console.error('Error en la respuesta: ', await response.text());
                alert("Error al obtener las etnias.");
            }
        } catch (error) {
            console.error("Ocurrió un error al intentar conectarse con el servidor:", error);
            alert("Ocurrió un error al intentar conectarse con el servidor.");
        }
    }

    etniasSelect(Etnias) {
        const selectEtnias = document.getElementById('etniaStudent');

        // Limpiar el select antes de agregar nuevas opciones
        selectEtnias.innerHTML = '<option value=""></option>';

        // Recorrer los municipios y agregar opciones al select
        Etnias.forEach(etnia => {
            const option = document.createElement('option');
            option.value = etnia.id;  // Asegúrate de que 'id' sea el campo correcto
            option.textContent = etnia.nombre;  // Asegúrate de que 'nombre' sea el campo correcto
            selectEtnias.appendChild(option);
        });
    }

    /* ================================================================================= */
    /* ===================================== PAISES ==================================== */
    /* ================================================================================= */
    async fetchPaises() {
        try {
            let response = await fetch(URL_PAISES_GET, {
                method: "GET",
                headers: {
                    "Accept": "application/json",
                    "authorization": `Bearer ${this.token}`
                },
                credentials: 'include'
            });

            if (response.ok) {
                let dataPaises = await response.json();
                console.log('Paises obtenidos: ', dataPaises);
                this.paisesSelect(dataPaises);
            } else {
                console.error('Error en la respuesta: ', await response.text());
                alert("Error al obtener los paises.");
            }
        } catch (error) {
            console.error("Ocurrió un error al intentar conectarse con el servidor:", error);
            alert("Ocurrió un error al intentar conectarse con el servidor.");
        }
    }

    paisesSelect(paises) {
        const selectPaises = document.getElementById('paisOrigenStudent');

        // Limpiar el select antes de agregar nuevas opciones
        selectPaises.innerHTML = '<option value=""></option>';

        // Recorrer los países y agregar opciones al select
        paises.forEach(pais => {
            const option = document.createElement('option');
            option.value = pais.id;  // Asegúrate de que 'id' sea el campo correcto
            option.textContent = `${pais.emojibandera} ${pais.nombre}`;  // Agregar la bandera y el nombre
            selectPaises.appendChild(option);
        });
    }

    /* ================================================================================= */
    /* ============================ PUT STUDENTS INFORMATION =========================== */
    /* ================================================================================= */
    async updateInformation() {
        let universidadGrado = document.getElementById('universidadGradoStudent').value;
        let numeroDocumento = document.getElementById('numeroDocumentoStudent').value;
        let nombres = document.getElementById('primerNombre').value;
        let idZonaProcedenciaStudent = document.getElementById('zonaProcedenciaStudent').value;
        let idTipoEntidadStudent = document.getElementById('tipoEntidadStudent').value;
        let idSexoStudent = document.getElementById('sexoStudent').value;
        let idPaisOrigenStudent = document.getElementById('paisOrigenStudent').value;
        let idMunicipioOrigenStudent = document.getElementById('municipioOrigenStudent').value;
        let idEtniaStudent = document.getElementById('etniaStudent').value;
        let idCentroSecundariaStudent = document.getElementById('centroSecundariaStudent').value;
        let fechaNacimientoStudent = document.getElementById('fechaNacimientoStudent').value;
        let codigoUnicoStudent = document.getElementById('codigoUnicoStudent').value;
        let correoInstitucionalStudent = document.getElementById('correoInstitucionalStudent').value;
        let correoStudent = document.getElementById('correoStudent').value;
        let primerApellido1Student = document.getElementById('primerApellido1Student').value;
        let segundoApellidoStudent = document.getElementById('segundoApellidoStudent').value;

        if (!universidadGrado || !numeroDocumento || !nombres || !idZonaProcedenciaStudent || !idTipoEntidadStudent || !idSexoStudent || !idPaisOrigenStudent || !idMunicipioOrigenStudent || !idEtniaStudent || !idCentroSecundariaStudent || !fechaNacimientoStudent || !codigoUnicoStudent || !correoInstitucionalStudent || !correoStudent || !primerApellido1Student || !segundoApellidoStudent) {
            alert('Por favor, llene todos los campos.');
            return;
        }

        let credentialsUpdateInformation = {
            universidadGrado: universidadGrado,
            numeroDocumento: numeroDocumento,
            nombres: nombres,
            idZonaProcedencia: idZonaProcedenciaStudent,
            idTipoEntidad: idTipoEntidadStudent,
            idSexo: idSexoStudent,
            idPaisOrigen: idPaisOrigenStudent,
            idMunicipioOrigen: idMunicipioOrigenStudent,
            idEtnia: idEtniaStudent,
            idCentroSecundaria: idCentroSecundariaStudent,
            fechaNacimiento: fechaNacimientoStudent,
            codigoUnico: codigoUnicoStudent,
            correoInstitucional: correoInstitucionalStudent,
            correo: correoStudent,
            apellido1: primerApellido1Student,
            apellido2: segundoApellidoStudent
        }

        console.log('Enviando credenciales: ', JSON.stringify(credentialsUpdateInformation));

        try {
            let response = await fetch(URL_ESTUDIANTES_PUT, {
                method: "PUT",
                headers: {
                    "Accept": "application/json,application/problem+json",
                    "Content-Type": "application+json",
                    "authorization": `Bearer ${this.state.token}`
                },
                body: JSON.stringify(credentialsUpdateInformation),
                credentials: 'include'
            });

            console.log("Estado de la respuesta: ", response.status);

            if (response.ok) {
                let data = await response.json();
                console.log('Datos recibidos: ', data);
                alert('Datos actualizados correctamente');
            } else {
                console.log('Error en la respuesta: ', await response.text());
                alert("Error al enviar los datos");
            }
        } catch (error) {
            console.error("Ocurrió un error al intentar conectarse con el servidor:", error);
            alert("Ocurrió un error al intentar conectarse con el servidor.");
        }
    }

    showPersonalInformation() {
        document.getElementById('personalInformationContainer').style.display = 'block';
        document.getElementById('studensInscriptionContainer').style.display = 'none';
    }

    showStudentsInscription() {
        document.getElementById('personalInformationContainer').style.display = 'none';
        document.getElementById('studensInscriptionContainer').style.display = 'block';
    }

    showUpdateForm() {
        document.getElementById('change-container-reingreso').style.display = 'none';
        document.getElementById('update-container-reingreso').style.display = 'block';
    }

    showOriginalContent() {
        document.getElementById('change-container-reingreso').style.display = 'block';
        document.getElementById('update-container-reingreso').style.display = 'none';
    }
}

Reingreso.template = 'owl.Reingreso';
registry.category('actions').add('owl.action_reingreso', Reingreso);