/** @odoo-module **/

import { registry } from '@web/core/registry';
const { Component } = owl;

export class Principal extends Component {
    setup() {
        // No es necesario hacer nada aquí en este momento
    }

    async toNuevoIngreso(){
        try{
            window.location.replace('/web#action=owl.action_bienvenido_nuevo_ingreso');
        } catch{
            console.log('Error al dirigir a la Interfaz de Bienvenido Nuevo Ingreso', error);
        }
    }

    async toReingreso() {
        try {
            window.location.replace('/web#action=owl.action_login');
        } catch {
            console.log('Error al dirigir a la Interfaz de Login', error);
        }
    }
}

Principal.template = 'owl.Principal';
registry.category('actions').add('owl.action_principal', Principal);