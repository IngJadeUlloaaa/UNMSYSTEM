/** @odoo-module **/
import { registry } from '@web/core/registry';
import { setCookie } from './cookieReingresos.js'; // Asegúrate de tener la función setCookie en utils.js

const { Component } = owl;

// LOGIN
const API_URL_LOGIN = "https://192.168.23.248:4500/api/v1/auth/login";

export class Login extends Component {
    setup() {
        this.token = null;
    }

    async toReingreso() {
        let usernameR = document.getElementById('usernameReingreso').value;
        let passwordR = document.getElementById('passwordReingreso').value;

        if (!usernameR || !passwordR) {
            alert("Por favor, llene todos los campos");
            return;
        }

        let credentialsReingreso = {
            username: usernameR,
            passwd: passwordR
        }
        console.log(credentialsReingreso)

       // window.location.replace('/web#action=owl.action_reingreso');

        console.log("Enviando Credenciales: ", JSON.stringify(credentialsReingreso));

        try {
            let response = await fetch(API_URL_LOGIN, {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify(credentialsReingreso)
            });

            console.log("Estado de la respuesta: ", response.status);

            if (response.ok) {
                let data = await response.json();
                this.token = data.accessToken;
                setCookie('reingreso_Token', this.token, 1); // Corregido 'this.token'

                console.log("Token Reingreso Recibido: ", this.token);
                alert("Sesión Iniciada Correctamente");

                window.location.replace('/web#action=owl.action_reingreso');
            } else {
                alert("Credenciales Incorrectas");
            }
        } catch (error) {
            console.error("Error en la solicitud: ", error);
            alert("Ocurrió un Error al Intentar Conectarse al Servidor");
        }
    }
}

Login.template = 'owl.Login';
registry.category('actions').add('owl.action_login', Login);